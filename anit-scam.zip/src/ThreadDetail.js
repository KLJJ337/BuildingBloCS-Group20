import React from "react";


function ThreadList() {
    return (
      <div className="firstCorner">
        
        <div className="MainThread">
            <div>
                <p>Username</p>
            </div> 
            <div>
                <h2>Title</h2>
                <p>Content</p>
            </div> 

                
                

            </div>
      </div>
    );
  }
  
  export default ThreadList;